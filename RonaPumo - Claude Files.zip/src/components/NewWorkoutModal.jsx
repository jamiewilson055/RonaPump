import { useState } from 'react'
import { supabase } from '../lib/supabase'

const SCORE_TYPES = ['Time', 'Rounds + Reps', 'Reps', 'Calories', 'Distance', 'Load', 'None']

export default function NewWorkoutModal({ onClose, onSaved, session, isAdmin }) {
  const [form, setForm] = useState({
    name: '',
    description: '',
    score_type: 'None',
    estimated_duration_mins: '',
    estimated_duration_min: '',
    estimated_duration_max: '',
    equipment: [],
    workout_types: [],
    categories: [],
    movement_categories: [],
    body_parts: [],
  })

  function toggleArray(field, val) {
    setForm(prev => {
      const arr = [...prev[field]]
      const idx = arr.indexOf(val)
      if (idx >= 0) arr.splice(idx, 1); else arr.push(val)
      return { ...prev, [field]: arr }
    })
  }

  async function handleSave(submitForReview = false, adminVisibility = null) {
    if (!form.description.trim()) { alert('Description is required.'); return }
    let visibility = 'private'
    if (adminVisibility) visibility = adminVisibility
    else if (isAdmin) visibility = 'official'
    else if (submitForReview) visibility = 'pending'

    const { error } = await supabase.from('workouts').insert({
      name: form.name.trim() || null,
      description: form.description.trim(),
      score_type: form.score_type,
      estimated_duration_mins: form.estimated_duration_mins ? parseInt(form.estimated_duration_mins) : null,
      estimated_duration_min: form.estimated_duration_min ? parseInt(form.estimated_duration_min) : null,
      estimated_duration_max: form.estimated_duration_max ? parseInt(form.estimated_duration_max) : null,
      equipment: form.equipment.length ? form.equipment : ['Bodyweight'],
      workout_types: form.workout_types.length ? form.workout_types : ['For Time'],
      categories: form.categories,
      movement_categories: form.movement_categories.length ? form.movement_categories : [],
      body_parts: form.body_parts.length ? form.body_parts : [],
      source: 'user-created',
      created_by: session?.user?.id || null,
      visibility,
      submitted_at: submitForReview ? new Date().toISOString() : null,
    })
    if (error) { alert('Error: ' + error.message); return }
    onSaved()
  }

  return (
    <div className="mo" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="mc">
        <h2>{isAdmin ? 'New Official Workout' : 'Create Workout'}</h2>
        {!isAdmin && (
          <div style={{ fontSize: '12px', color: 'var(--tx3)', marginBottom: '12px', lineHeight: 1.5 }}>
            Create a workout for yourself, or submit it for community review. Private workouts are only visible to you.
          </div>
        )}

        <label>Name</label>
        <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. The Grind" />

        <label>Description / Details</label>
        <div className="fmt-bar">
          <button type="button" className="fmt-btn" title="Add bullet point" onClick={() => {
            const ta = document.getElementById('wk-desc')
            if (!ta) return
            const start = ta.selectionStart
            const before = form.description.slice(0, start)
            const after = form.description.slice(start)
            const needsNewline = before.length > 0 && !before.endsWith('\n')
            const insert = (needsNewline ? '\n' : '') + '• '
            setForm({ ...form, description: before + insert + after })
            setTimeout(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = start + insert.length }, 0)
          }}>• Bullet</button>
          <button type="button" className="fmt-btn" title="Add sub-bullet" onClick={() => {
            const ta = document.getElementById('wk-desc')
            if (!ta) return
            const start = ta.selectionStart
            const before = form.description.slice(0, start)
            const after = form.description.slice(start)
            const needsNewline = before.length > 0 && !before.endsWith('\n')
            const insert = (needsNewline ? '\n' : '') + '  • '
            setForm({ ...form, description: before + insert + after })
            setTimeout(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = start + insert.length }, 0)
          }}>  ◦ Sub-bullet</button>
          <button type="button" className="fmt-btn" title="Bold selected text" onClick={() => {
            const ta = document.getElementById('wk-desc')
            if (!ta) return
            const start = ta.selectionStart
            const end = ta.selectionEnd
            const selected = form.description.slice(start, end)
            if (selected) {
              const before = form.description.slice(0, start)
              const after = form.description.slice(end)
              setForm({ ...form, description: before + '**' + selected + '**' + after })
              setTimeout(() => { ta.focus(); ta.selectionStart = start; ta.selectionEnd = end + 4 }, 0)
            } else {
              const before = form.description.slice(0, start)
              const after = form.description.slice(start)
              setForm({ ...form, description: before + '****' + after })
              setTimeout(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = start + 2 }, 0)
            }
          }}><b>B</b> Bold</button>
          <button type="button" className="fmt-btn" title="Add section header" onClick={() => {
            const ta = document.getElementById('wk-desc')
            if (!ta) return
            const start = ta.selectionStart
            const before = form.description.slice(0, start)
            const after = form.description.slice(start)
            const needsNewline = before.length > 0 && !before.endsWith('\n')
            const insert = (needsNewline ? '\n' : '') + '--- '
            setForm({ ...form, description: before + insert + after })
            setTimeout(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = start + insert.length }, 0)
          }}>— Section</button>
        </div>
        <textarea id="wk-desc" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Full workout details...&#10;&#10;Use the toolbar above to add bullet points" style={{ minHeight: '140px' }} />

        <label>Score Type</label>
        <div className="st-sel">
          {SCORE_TYPES.map(t => (
            <button key={t} className={`st-opt${form.score_type === t ? ' on' : ''}`}
              onClick={() => setForm({ ...form, score_type: t })}>{t}</button>
          ))}
        </div>

        <label>Duration (exact minutes, if known)</label>
        <input type="number" value={form.estimated_duration_mins} onChange={e => setForm({ ...form, estimated_duration_mins: e.target.value })} placeholder="e.g. 30" />

        <label>Duration Range (if exact is unknown)</label>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <input type="number" value={form.estimated_duration_min} onChange={e => setForm({ ...form, estimated_duration_min: e.target.value })} placeholder="Min" style={{ width: '80px' }} />
          <span style={{ color: 'var(--tx3)' }}>–</span>
          <input type="number" value={form.estimated_duration_max} onChange={e => setForm({ ...form, estimated_duration_max: e.target.value })} placeholder="Max" style={{ width: '80px' }} />
          <span style={{ color: 'var(--tx3)', fontSize: '12px' }}>minutes</span>
        </div>

        <label>Equipment</label>
        <div className="cr">
          {['Barbell', 'Bench', 'Bike (Assault/Echo)', 'Bodyweight', 'Box', 'Dumbbell', 'Kettlebell', 'Medicine Ball', 'Pull-Up Bar', 'Rower', 'Sandbag', 'Ski Erg', 'Sled', 'Speed Rope', 'Weighted Vest'].map(eq => (
            <button key={eq} className={`ch${form.equipment.includes(eq) ? ' on' : ''}`}
              onClick={() => toggleArray('equipment', eq)}>{eq}</button>
          ))}
        </div>

        <label>Workout Type</label>
        <div className="cr">
          {['AMRAP', 'EMOM', 'For Calories', 'For Distance', 'For Time', 'Interval', 'Ladder', 'Rounds', 'Strength'].map(t => (
            <button key={t} className={`ch${form.workout_types.includes(t) ? ' on' : ''}`}
              onClick={() => toggleArray('workout_types', t)}>{t}</button>
          ))}
        </div>

        <label>Category</label>
        <div className="cr">
          {['Cardio Only', 'DB Only', 'RonaAbs', 'Harambe Favorites', 'Home Gym', 'Hotel Workouts', 'HYROX', 'Murph', 'Outdoor', 'Track Workouts'].map(c => (
            <button key={c} className={`ch${form.categories.includes(c) ? ' on' : ''}`}
              onClick={() => toggleArray('categories', c)}>{c}</button>
          ))}
        </div>

        <label>Movement Type</label>
        <div className="cr">
          {['Bench Press', 'Burpee', 'DB Snatch', 'Deadlift', 'Farmers Carry', 'Jump', 'Lunge', 'Pull-Up', 'Push-Up', 'Run', 'Shoulder Press', 'Squat'].map(m => (
            <button key={m} className={`ch${form.movement_categories.includes(m) ? ' on' : ''}`}
              onClick={() => toggleArray('movement_categories', m)}>{m}</button>
          ))}
        </div>

        <label>Body Part</label>
        <div className="cr">
          {['Upper Body', 'Lower Body', 'Full Body'].map(b => (
            <button key={b} className={`ch${form.body_parts.includes(b) ? ' on' : ''}`}
              onClick={() => toggleArray('body_parts', b)}>{b}</button>
          ))}
        </div>

        <div className="mf" style={{ gap: '8px' }}>
          <button className="ab" onClick={onClose}>Cancel</button>
          {isAdmin ? (
            <>
              <button className="ab" onClick={() => handleSave(false, 'private')}>Save to My Workouts</button>
              <button className="ab p" onClick={() => handleSave(false, 'official')}>Add as Official 🦍</button>
            </>
          ) : (
            <>
              <button className="ab" onClick={() => handleSave(false)}>Save Private</button>
              <button className="ab p" onClick={() => handleSave(true)}>Submit to Community</button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
