import { useState, useEffect, useRef } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { formatDesc, bestScore, compareLogs } from '../lib/workoutFormat'
import WorkoutTimer from '../components/WorkoutTimer'
import WorkoutEditModal from '../components/WorkoutEditModal'
import ShareImage from '../components/ShareImage'
import StoryCard from '../components/StoryCard'
import Auth from '../components/Auth'
import { previewWorkout } from '../components/SignupGate'
import '../App.css'



function SimilarCard({ workout: s }) {
  const [open, setOpen] = useState(false)
  const [desc, setDesc] = useState(s.description || null)

  useEffect(() => {
    if (open && !desc) {
      supabase.from('workouts').select('description').eq('id', s.id).single().then(({ data }) => {
        if (data) setDesc(data.description || '')
      })
    }
  }, [open, desc, s.id])

  return (
    <div className={`similar-card${open ? ' open' : ''}`}>
      <div className="similar-hd" onClick={() => setOpen(!open)}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '12px', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {s.name || 'Unnamed'}
          </div>
          <div style={{ fontSize: '11px', color: 'var(--tx2)', marginTop: '2px' }}>
            {s.equipment?.filter(e => e !== 'Bodyweight').slice(0, 3).join(', ')}
            {s.estimated_duration_mins ? ` · ${s.estimated_duration_mins}m` : ''}
            {s.score_type && s.score_type !== 'None' ? ` · ${s.score_type}` : ''}
          </div>
        </div>
        <span style={{ color: 'var(--tx3)', fontSize: '10px', flexShrink: 0 }}>{open ? '▾' : '▸'}</span>
      </div>
      {open && (
        <div className="similar-body">
          <div className="dsc" style={{ fontSize: '12px', padding: '8px 0 4px' }}>{desc ? formatDesc(desc) : <span style={{ color: 'var(--tx3)' }}>Loading...</span>}</div>
          <div className="wtg" style={{ padding: '4px 0' }}>
            {s.equipment?.filter(q => q !== 'Bodyweight').map(q => <span key={q} className="tg te">{q}</span>)}
            {s.movement_categories?.filter(m => !['General', 'Cardio'].includes(m)).slice(0, 4).map(m => <span key={m} className="tg tm">{m}</span>)}
            {s.workout_types?.filter(t => t !== 'General').map(t => <span key={t} className="tg tw">{t}</span>)}
          </div>
        </div>
      )}
    </div>
  )
}

export default function WorkoutPage() {
  const { slug } = useParams()
  const [workout, setWorkout] = useState(null)
  const [loading, setLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [showTimer, setShowTimer] = useState(false)
  const [showShareImage, setShowShareImage] = useState(false)
  const [showStoryCard, setShowStoryCard] = useState(false)
  const [copied, setCopied] = useState(false)
  const [session, setSession] = useState(null)
  const [sessionReady, setSessionReady] = useState(false)
  const [showAuth, setShowAuth] = useState(false)
  const [profile, setProfile] = useState(null)
  const [addingLog, setAddingLog] = useState(false)
  const [logScore, setLogScore] = useState('')
  const [logDate, setLogDate] = useState(new Date().toISOString().slice(0, 10))
  const [logNotes, setLogNotes] = useState('')
  const [logRx, setLogRx] = useState(true)
  const [lastLogScore, setLastLogScore] = useState(null)
  const [isFav, setIsFav] = useState(false)
  const [similar, setSimilar] = useState([])
  const [showSimilar, setShowSimilar] = useState(false)
  const [showCollections, setShowCollections] = useState(false)
  const [collections, setCollections] = useState([])
  const [editMode, setEditMode] = useState(null) // null | 'edit' | 'remix'
  const [logSort, setLogSort] = useState('score') // leaderboard defaults to best score on top
  const [editingLogId, setEditingLogId] = useState(null)
  const [editLogForm, setEditLogForm] = useState(null)
  const isAdmin = profile?.is_admin || false

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s)
      if (s) loadProfile(s.user.id)
      setSessionReady(true)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s)
      if (s) loadProfile(s.user.id)
    })
    return () => subscription.unsubscribe()
  }, [])

  async function loadProfile(userId) {
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).single()
    if (data) setProfile(data)
    const { data: colls } = await supabase.from('user_collections').select('*').eq('user_id', userId).order('name')
    if (colls) setCollections(colls)
  }

  useEffect(() => { loadWorkout() }, [slug])
  const [gateLocked, setGateLocked] = useState(false)
  const countedRef = useRef(null)
  useEffect(() => {
    if (sessionReady && !session && workout && countedRef.current !== workout.id) {
      countedRef.current = workout.id
      setGateLocked(!previewWorkout(workout.id))
    }
    if (session) setGateLocked(false)
  }, [sessionReady, session, workout])
  useEffect(() => { if (session && workout) checkFavorite() }, [session, workout])

  async function loadWorkout() {
    setLoading(true)
    const { data, error } = await supabase
      .from('workouts')
      .select('*, performance_log(*, profiles(display_name))')
      .order('completed_at', { referencedTable: 'performance_log', ascending: false })

    if (error || !data) { setNotFound(true); setLoading(false); return }

    const match = data.find(w => {
      if (!w.name) return false
      const s = w.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
      return s === slug
    })

    if (!match) { setNotFound(true); setLoading(false); return }
    setWorkout(match)

    const sim = data.filter(w => w.id !== match.id && w.name && w.visibility === 'official').filter(w => {
      let score = 0
      if (match.equipment?.some(e => w.equipment?.includes(e))) score++
      if (match.workout_types?.some(t => w.workout_types?.includes(t))) score++
      if (match.movement_categories?.some(m => w.movement_categories?.includes(m))) score++
      if (match.body_parts?.some(b => w.body_parts?.includes(b))) score++
      return score >= 2
    }).slice(0, 5)
    setSimilar(sim)
    setLoading(false)
  }

  async function checkFavorite() {
    const { data } = await supabase.from('user_favorites').select('workout_id')
      .eq('user_id', session.user.id).eq('workout_id', workout.id).single()
    setIsFav(!!data)
  }

  async function toggleFavorite() {
    if (!session) return
    if (isFav) {
      await supabase.from('user_favorites').delete().eq('user_id', session.user.id).eq('workout_id', workout.id)
      setIsFav(false)
    } else {
      await supabase.from('user_favorites').insert({ user_id: session.user.id, workout_id: workout.id })
      setIsFav(true)
    }
  }

  async function saveLog() {
    if (!session || !workout) return
    const scoreVal = logScore.trim() || null
    await supabase.from('performance_log').insert({
      user_id: session.user.id, workout_id: workout.id,
      completed_at: logDate, score: scoreVal,
      notes: logNotes.trim() || null, is_rx: logRx,
    })
    setLastLogScore(scoreVal)
    setAddingLog(false); setLogScore(''); setLogNotes(''); setLogRx(true)
    setShowStoryCard(true)
    try { localStorage.removeItem('ronapump_active_workout') } catch {}
    loadWorkout()
  }

  function startEditLog(entry) {
    setEditingLogId(entry.id)
    setEditLogForm({ score: entry.score || '', completed_at: entry.completed_at || '', notes: entry.notes || '', is_rx: entry.is_rx !== false })
  }

  async function saveEditLog() {
    if (!editLogForm || !editingLogId) return
    await supabase.from('performance_log').update({
      score: editLogForm.score.trim() || null,
      completed_at: editLogForm.completed_at,
      notes: editLogForm.notes.trim() || null,
      is_rx: editLogForm.is_rx,
    }).eq('id', editingLogId)
    setEditingLogId(null)
    setEditLogForm(null)
    loadWorkout()
  }

  async function deleteLog(logId) {
    if (!confirm('Delete this log entry?')) return
    await supabase.from('performance_log').delete().eq('id', logId)
    loadWorkout()
  }

  function shareWorkout() {
    if (!workout) return
    let text = ''
    if (workout.name) text += workout.name + '\n\n'
    text += workout.description || ''
    if (workout.estimated_duration_mins) text += `\n\n⏱ ${workout.estimated_duration_mins} min`
    else if (workout.estimated_duration_min && workout.estimated_duration_max) text += `\n\n⏱ ${workout.estimated_duration_min}-${workout.estimated_duration_max} min`
    if (workout.equipment?.filter(e => e !== 'Bodyweight').length) text += `\n🏋 ${workout.equipment.filter(e => e !== 'Bodyweight').join(', ')}`
    text += `\n\n🦍 — RonaPump | ${window.location.href}`
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  function saveActiveWorkout() {
    if (!workout) return
    const slug = (workout.name || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
    try { localStorage.setItem('ronapump_active_workout', JSON.stringify({ id: workout.id, name: workout.name || 'Workout', slug, startedAt: Date.now() })) } catch {}
  }

  function startEdit() { setEditMode('edit') }
  function startRemix() {
    if (!session) return
    setEditMode('remix')
  }


  async function deleteWorkout() {
    if (!confirm('Permanently delete this workout? This cannot be undone.')) return
    await supabase.from('workouts').delete().eq('id', workout.id)
    window.location.href = '/'
  }

  async function addToCollection(collId) {
    if (!session || !workout) return
    const { error } = await supabase.from('collection_workouts').insert({ collection_id: collId, workout_id: workout.id })
    if (error && error.code === '23505') { alert('Already in this collection!'); return }
    setShowCollections(false)
  }

  if (loading) return <div className="app"><div className="loading">Loading workout...</div></div>

  if (notFound) {
    return (
      <div className="app">
        <div className="wp-header"><Link to="/" className="wp-back">← Back to RonaPump</Link></div>
        <div className="pr-empty" style={{ marginTop: '20px' }}>
          <h3>Workout not found 🦍</h3>
          <p style={{ marginTop: '8px' }}>This workout may have been removed or the link is incorrect.</p>
          <Link to="/" className="ab p" style={{ display: 'inline-block', marginTop: '12px', textDecoration: 'none' }}>Browse All Workouts</Link>
        </div>
      </div>
    )
  }

  const w = workout
  const durDisplay = w.estimated_duration_mins
    ? `${w.estimated_duration_mins}m`
    : (w.estimated_duration_min && w.estimated_duration_max)
      ? `${w.estimated_duration_min}-${w.estimated_duration_max}m`
      : null
  const scoreLabel = w.score_type === 'Time' ? 'Time' : w.score_type === 'Rounds + Reps' ? 'Score' : w.score_type === 'Calories' ? 'Cals' : w.score_type === 'Reps' ? 'Reps' : w.score_type === 'Distance' ? 'Distance' : w.score_type === 'Load' ? 'Weight' : 'Result'
  const bs = bestScore(w)
  const leaderboardPl = (w.performance_log || []).filter(p => p.notes !== 'Quick logged')
  const totalLoggers = new Set(leaderboardPl.map(p => p.user_id)).size

  // Rx ALWAYS above Scaled, then by properly parsed score — shared compareLogs helper.
  // Unscored workouts fall back to date ordering.
  const effSort = w.score_type === 'None' ? 'date' : logSort
  const sortedPl = (() => {
    const sorted = [...leaderboardPl]
    if (effSort === 'score') {
      sorted.sort((a, b) => compareLogs(a, b, w.score_type))
    } else {
      sorted.sort((a, b) => (b.completed_at || '').localeCompare(a.completed_at || ''))
    }
    return sorted
  })()

  return (
    <div className="app">
      <div className="wp-header">
        <Link to="/" className="wp-back">← Back to RonaPump</Link>
        <div className="logo" style={{ cursor: 'pointer' }} onClick={() => window.location.href = '/'}><b>RONA</b>PUMP</div>
      </div>

      <div className="wp-card">
        <div className="wp-title-row">
          <h1 className="wp-title">{w.name || 'Unnamed Workout'}</h1>
          {w.auto_named && <span className="auto-tag">auto</span>}
        </div>

        <div className="wp-meta">
          {durDisplay && <span className="wdr">{durDisplay}</span>}
          {w.score_type !== 'None' && <span className="wst">{w.score_type}</span>}
        </div>

        <div className="wp-tags">
          {w.equipment?.filter(q => q !== 'Bodyweight').map(q => <span key={q} className="tg te">{q}</span>)}
          {w.movement_categories?.filter(m => !['General', 'Cardio'].includes(m)).slice(0, 8).map(m => <span key={m} className="tg tm">{m}</span>)}
          {w.categories?.map(c => <span key={c} className="tg tc">{c}</span>)}
          {w.workout_types?.filter(t => t !== 'General').map(t => <span key={t} className="tg tw">{t}</span>)}
          {w.body_parts?.map(b => <span key={b} className="tg tb">{b}</span>)}
        </div>

        {gateLocked ? (
          <div className="gate-lock-wrap">
            <div className="gate-blur"><div className="wp-desc">{formatDesc(w.description)}</div></div>
            <div className="gate-cta">
              <div className="gate-cta-txt">🦍 You've used your free previews</div>
              <button className="gate-cta-btn" onClick={() => setShowAuth(true)}>Sign Up Free to Unlock 800+ Workouts</button>
            </div>
          </div>
        ) : (
          <div className="wp-desc">{formatDesc(w.description)}</div>
        )}

        <div className="wp-info">
          <span>Equipment: {w.equipment?.join(', ') || 'Bodyweight'}</span>
          {w.movement_categories?.length > 0 && <span>Movements: {w.movement_categories.join(', ')}</span>}
        </div>

        {/* Leaderboard — matches WorkoutCard */}
        <div className="plog">
          <div className="plog-hdr">
            <h4>Leaderboard {w.score_type !== 'None' && <span className="st-badge">{w.score_type}</span>}
              {totalLoggers > 0 && <span className="st-badge" style={{ background: 'var(--grn-d)', color: 'var(--grn)' }}>{totalLoggers} athlete{totalLoggers !== 1 ? 's' : ''}</span>}
            </h4>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              {leaderboardPl.length > 1 && (
                <select className="ssel" value={effSort} onChange={e => setLogSort(e.target.value)} style={{ width: 'auto', fontSize: '10px', padding: '3px 6px' }}>
                  <option value="date">By Date</option>
                  <option value="score">By {w.score_type === 'Time' ? 'Time' : 'Score'}</option>
                </select>
              )}
              <span className="plog-add" onClick={() => { if (!session) return; setAddingLog(!addingLog) }}>{addingLog ? 'Cancel' : '+ Log Result'}</span>
            </div>
          </div>
          {sortedPl.length > 0 && (
            <table className="plog-table">
              <thead><tr><th>Athlete</th><th>Date</th><th>{scoreLabel}</th><th>Notes</th><th></th></tr></thead>
              <tbody>
                {sortedPl.map((e, idx) => {
                  const isBest = e.score === bs && leaderboardPl.length > 1
                  const isEditingThis = editingLogId === e.id
                  const rank = effSort === 'score' ? idx + 1 : null
                  const isMine = e.user_id === session?.user?.id

                  if (isEditingThis && editLogForm) {
                    return (
                      <tr key={e.id}>
                        <td style={{ fontWeight: 600, color: 'var(--tx2)', fontSize: '11px' }}>{e.profiles?.display_name || 'Anonymous'}</td>
                        <td><input type="date" value={editLogForm.completed_at} onChange={ev => setEditLogForm({ ...editLogForm, completed_at: ev.target.value })} style={{ background: 'var(--bg)', border: '1px solid var(--brd)', borderRadius: '3px', color: 'var(--tx)', padding: '2px 4px', fontSize: '11px', width: '100%' }} /></td>
                        <td><input value={editLogForm.score} onChange={ev => setEditLogForm({ ...editLogForm, score: ev.target.value })} style={{ background: 'var(--bg)', border: '1px solid var(--brd)', borderRadius: '3px', color: 'var(--tx)', padding: '2px 4px', fontSize: '11px', width: '100%' }} /></td>
                        <td><textarea className="plog-edit-notes" rows={1} value={editLogForm.notes} onChange={ev => { setEditLogForm({ ...editLogForm, notes: ev.target.value }); ev.target.style.height = 'auto'; ev.target.style.height = ev.target.scrollHeight + 'px' }} style={{ background: 'var(--bg)', border: '1px solid var(--brd)', borderRadius: '3px', color: 'var(--tx)', padding: '2px 4px', fontSize: '11px', width: '100%', resize: 'none', overflow: 'hidden', fontFamily: 'inherit', lineHeight: '1.4', display: 'block' }} /></td>
                        <td style={{ whiteSpace: 'nowrap' }}>
                          <label className="rx-toggle" style={{ fontSize: '10px', gap: '2px', marginRight: '6px' }}>
                            <input type="checkbox" checked={editLogForm.is_rx} onChange={ev => setEditLogForm({ ...editLogForm, is_rx: ev.target.checked })} />
                            <span className={editLogForm.is_rx ? 'rx-on' : 'rx-off'}>Rx</span>
                          </label>
                          <span className="del-entry" onClick={saveEditLog} style={{ color: 'var(--grn)', marginRight: '4px' }}>✓</span>
                          <span className="del-entry" onClick={() => { setEditingLogId(null); setEditLogForm(null) }}>✕</span>
                        </td>
                      </tr>
                    )
                  }

                  return (
                    <tr key={e.id} className={isMine ? 'my-log' : ''}>
                      <td className="lb-name">
                        {rank && isBest && <span className="lb-medal">🥇</span>}
                        {rank === 2 && <span className="lb-medal">🥈</span>}
                        {rank === 3 && <span className="lb-medal">🥉</span>}
                        <span style={{ fontWeight: isMine ? 700 : 500 }}>{e.profiles?.display_name || 'Anonymous'}</span>
                      </td>
                      <td>{e.completed_at || '—'}</td>
                      <td className={isBest ? 'best' : ''}>
                        {e.score ? e.score : '✓'}{isBest ? ' ★' : ''}
                        {e.is_rx === false && <span className="scaled-tag">Scaled</span>}
                        {e.is_rx === true && e.score && <span className="rx-tag">Rx</span>}
                      </td>
                      <td style={{ fontFamily: "'DM Sans'", fontSize: '11px' }}>{e.notes || '—'}</td>
                      <td style={{ whiteSpace: 'nowrap' }}>
                        {(isMine || isAdmin) && <span className="del-entry" onClick={(ev) => { ev.stopPropagation(); startEditLog(e) }} style={{ marginRight: '4px' }} title="Edit">✎</span>}
                        {(isMine || isAdmin) && <span className="del-entry" onClick={(ev) => { ev.stopPropagation(); deleteLog(e.id) }}>✕</span>}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          )}
          {addingLog && session && (
            <div className="plog-form" style={{ marginTop: '6px' }}>
              <input placeholder={`${scoreLabel} (optional)`} value={logScore} onChange={e => setLogScore(e.target.value)} />
              <input type="date" value={logDate} onChange={e => setLogDate(e.target.value)} />
              <textarea className="plog-notes" rows={1} placeholder="Notes (optional)" value={logNotes} onChange={e => { setLogNotes(e.target.value); e.target.style.height = 'auto'; e.target.style.height = e.target.scrollHeight + 'px' }} />
              <label className="rx-toggle" title="Rx = prescribed weights/movements">
                <input type="checkbox" checked={logRx} onChange={e => setLogRx(e.target.checked)} />
                <span className={logRx ? 'rx-on' : 'rx-off'}>Rx</span>
              </label>
              <button className="ab p" onClick={saveLog}>Save</button>
            </div>
          )}
        </div>

        {/* BUTTONS — identical order to WODCard and WorkoutCard:
            Start, Complete, Favorite, Save, Remix, Similar, Instagram, Story Card, Share, Link, Edit (admin), Delete (admin) */}
        <div className="acts">
          <button className="ab p" onClick={() => { saveActiveWorkout(); setShowTimer(true) }} style={{ fontWeight: 600 }}>▶ Start Workout</button>
          <button className="ab p" onClick={() => { if (!session) return; setAddingLog(!addingLog) }} style={{ background: 'var(--grn-d)', color: 'var(--grn)', borderColor: 'var(--grn)' }}>{addingLog ? 'Cancel' : '✓ Complete Workout'}</button>
          <button className={`ab ${isFav ? '' : 'g'}`} onClick={toggleFavorite}>{isFav ? '★ Unfavorite' : '☆ Favorite'}</button>
          <button className="ab" onClick={() => { if (!session) return; setShowCollections(!showCollections) }}>{showCollections ? 'Hide' : '📁 Save'}</button>
          <button className="ab" onClick={startRemix}>🔀 Remix</button>
          <button className="ab" onClick={() => setShowSimilar(!showSimilar)}>{showSimilar ? 'Hide Similar' : '≈ Similar'}</button>
          <button className="ab" onClick={() => setShowShareImage(true)}>📸 Instagram</button>
          <button className="ab" onClick={() => setShowStoryCard(true)}>📱 Story Card</button>
          <button className="ab" onClick={shareWorkout}>📋 Share</button>
          {isAdmin && <button className="ab p" onClick={startEdit}>Edit</button>}
          {isAdmin && <button className="ab del" onClick={deleteWorkout}>Delete</button>}
        </div>

        {/* Collections picker */}
        {showCollections && (
          <div className="coll-picker">
            <div style={{ fontSize: '11px', color: 'var(--tx3)', marginBottom: '4px' }}>Add to collection:</div>
            {collections.length === 0 ? (
              <div style={{ fontSize: '11px', color: 'var(--tx3)' }}>No collections yet. Create one from the Collections tab.</div>
            ) : collections.map(c => (
              <button key={c.id} className="ab" onClick={() => addToCollection(c.id)}>📁 {c.name}</button>
            ))}
          </div>
        )}

        {/* Similar workouts — expandable cards matching WODCard and WorkoutCard */}
        {showSimilar && (
          <div className="similar-section">
            <h4 style={{ fontSize: '12px', fontFamily: "'JetBrains Mono', monospace", color: 'var(--tx3)', marginBottom: '6px' }}>Similar Workouts</h4>
            {similar.length === 0 ? (
              <div style={{ fontSize: '11px', color: 'var(--tx3)' }}>No similar workouts found.</div>
            ) : similar.map(s => (
              <SimilarCard key={s.id} workout={s} />
            ))}
          </div>
        )}

        {!session && (
          <div className="wp-cta">
            <p>Want to track your scores, build collections, and compete on the leaderboard?</p>
            <Link to="/" className="ab p" style={{ textDecoration: 'none', display: 'inline-block' }}>Join RonaPump 🦍</Link>
          </div>
        )}
      </div>

      <div className="wp-footer">
        <a href="https://www.instagram.com/ronapump/" target="_blank" rel="noopener noreferrer">📸 @ronapump</a>
        <span>•</span>
        <Link to="/">www.ronapump.com</Link>
      </div>

      {showTimer && <WorkoutTimer workout={w} onClose={() => setShowTimer(false)} session={session} onWorkoutsChanged={loadWorkout} />}
      {showShareImage && <ShareImage workout={w} onClose={() => setShowShareImage(false)} />}
      {showStoryCard && <StoryCard workout={w} score={lastLogScore} session={session} onClose={() => setShowStoryCard(false)} />}

      {editMode && (
        <WorkoutEditModal
          workout={workout}
          mode={editMode}
          session={session}
          onClose={() => setEditMode(null)}
          onSaved={() => { setEditMode(null); loadWorkout && loadWorkout() }}
        />
      )}
      {showAuth && <Auth onClose={() => setShowAuth(false)} />}
    </div>
  )
}
