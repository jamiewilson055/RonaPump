import { useState, useMemo, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import Filters from '../components/Filters'
import WorkoutCard from '../components/WorkoutCard'
import NewWorkoutModal from '../components/NewWorkoutModal'

const PP = 30

export default function WorkoutList({ workouts, tab, favorites, toggleFavorite, session, profile, isAdmin, onAuthRequired, onWorkoutsChanged, collections, onCollectionsChanged, onGenerateAI, preset }) {
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState('added')
  const [page, setPage] = useState(1)
  const [filters, setFilters] = useState({
    eq: [], eqEx: [], mv: [], mvEx: [], cat: [], wt: [], bp: [],
    durMin: null, durMax: null, includeNoDur: true
  })
  const [sourceFilter, setSourceFilter] = useState('all') // all, official, community, mine
  const [showNewModal, setShowNewModal] = useState(false)
  const [aiLoading, setAiLoading] = useState(false)
  const [aiError, setAiError] = useState('')
  const [aiActive, setAiActive] = useState(null) // the natural-language query that produced the current filters
  const [qlOpen, setQlOpen] = useState(false)
  const [qlText, setQlText] = useState('')
  const [qlLoading, setQlLoading] = useState(false)
  const [qlError, setQlError] = useState('')
  const [qlParsed, setQlParsed] = useState(null)
  const [qlSaved, setQlSaved] = useState(false)
  const [showFilters, setShowFilters] = useState(false)
  const [presetLabel, setPresetLabel] = useState(null)

  // Preset filters pushed from elsewhere (e.g. Longevity Focus Areas → "Train it")
  useEffect(() => {
    if (!preset?.filters) return
    setFilters({ eq: [], eqEx: [], mv: [], mvEx: [], cat: [], wt: [], bp: [], durMin: null, durMax: null, includeNoDur: true, ...preset.filters })
    setQuery(''); setPage(1); setPresetLabel(preset.label || 'Preset')
  }, [preset?.nonce])

  const allEquipment = useMemo(() => [...new Set(workouts.flatMap(w => w.equipment || []))].sort(), [workouts])
  const allMovements = useMemo(() => [...new Set(workouts.flatMap(w => w.movement_categories || []))].sort(), [workouts])
  const allCategories = useMemo(() => [...new Set(workouts.flatMap(w => w.categories || []))].sort(), [workouts])
  const allWorkoutTypes = useMemo(() => [...new Set(workouts.flatMap(w => w.workout_types || []))].sort(), [workouts])
  const allBodyParts = useMemo(() => [...new Set(workouts.flatMap(w => w.body_parts || []))].sort(), [workouts])

  const filtered = useMemo(() => {
    let w = [...workouts]

    if (tab === 'done') w = w.filter(x => x.my_log_count > 0)
    else if (tab === 'queue') w = w.filter(x => !x.my_log_count || x.my_log_count === 0)
    else if (tab === 'favs') w = w.filter(x => favorites.has(x.id))

    // Source filter
    if (sourceFilter === 'official') w = w.filter(x => x.visibility === 'official')
    else if (sourceFilter === 'community') w = w.filter(x => x.visibility === 'community')
    else if (sourceFilter === 'mine') w = w.filter(x => x.created_by === session?.user?.id && x.visibility !== 'official' && x.visibility !== 'community')

    // My Gym filter — only show workouts where all equipment is in user's gym
    if (sourceFilter === 'mygym' && profile?.my_equipment?.length > 0) {
      const myGym = new Set([...profile.my_equipment, 'Bodyweight'])
      w = w.filter(x => (x.equipment || []).every(eq => myGym.has(eq)))
    }

    if (query) {
      const q = query.toLowerCase()
      w = w.filter(x =>
        (x.name && x.name.toLowerCase().includes(q)) ||
        x.description.toLowerCase().includes(q) ||
        x.equipment?.some(e => e.toLowerCase().includes(q)) ||
        x.movement_categories?.some(m => m.toLowerCase().includes(q)) ||
        x.categories?.some(c => c.toLowerCase().includes(q)) ||
        x.workout_types?.some(t => t.toLowerCase().includes(q)) ||
        x.body_parts?.some(b => b.toLowerCase().includes(q))
      )
    }

    // Include filters (AND)
    if (filters.eq.length) w = w.filter(x => filters.eq.every(f => x.equipment?.includes(f)))
    if (filters.mv.length) w = w.filter(x => filters.mv.every(f => x.movement_categories?.includes(f)))
    if (filters.cat.length) w = w.filter(x => filters.cat.every(f => x.categories?.includes(f)))
    if (filters.wt.length) w = w.filter(x => filters.wt.every(f => x.workout_types?.includes(f)))
    if (filters.bp?.length) w = w.filter(x => filters.bp.every(f => x.body_parts?.includes(f)))

    // Exclude filters
    if (filters.eqEx?.length) w = w.filter(x => !filters.eqEx.some(f => x.equipment?.includes(f)))
    if (filters.mvEx?.length) w = w.filter(x => !filters.mvEx.some(f => x.movement_categories?.includes(f)))

    // Duration
    if (filters.durMin != null || filters.durMax != null) {
      const includeNoDur = filters.includeNoDur !== false
      w = w.filter(x => {
        const exact = x.estimated_duration_mins
        const rangeMin = x.estimated_duration_min
        const rangeMax = x.estimated_duration_max
        const hasAnyDur = exact || rangeMin || rangeMax
        if (!hasAnyDur) return includeNoDur

        // Build the effective min/max for this workout
        const effMin = rangeMin || exact || null
        const effMax = rangeMax || exact || null

        if (effMin == null && effMax == null) return includeNoDur
        // Workout's range overlaps with filter range
        if (filters.durMax != null && effMin > filters.durMax) return false
        if (filters.durMin != null && effMax < filters.durMin) return false
        return true
      })
    }

    // Effective duration for sorting (use exact, or midpoint of range, or min)
    function effDur(w) {
      if (w.estimated_duration_mins) return w.estimated_duration_mins
      if (w.estimated_duration_min && w.estimated_duration_max) return (w.estimated_duration_min + w.estimated_duration_max) / 2
      if (w.estimated_duration_min) return w.estimated_duration_min
      return null
    }

    if (sort === 'added') w.sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''))
    else if (sort === 'newest') w.sort((a, b) => (b.original_date || '').localeCompare(a.original_date || ''))
    else if (sort === 'oldest') w.sort((a, b) => (a.original_date || '9999').localeCompare(b.original_date || '9999'))
    else if (sort === 'name') w.sort((a, b) => (a.name || 'zzz').localeCompare(b.name || 'zzz'))
    else if (sort === 'dur_s') w.sort((a, b) => (effDur(a) || 999) - (effDur(b) || 999))
    else if (sort === 'dur_l') w.sort((a, b) => (effDur(b) || 0) - (effDur(a) || 0))

    return w
  }, [workouts, tab, query, filters, sort, favorites, sourceFilter, session, profile])

  const totalPages = Math.ceil(filtered.length / PP)
  const items = filtered.slice((page - 1) * PP, page * PP)

  const hasFilters = query || sourceFilter !== 'all' || filters.eq.length || filters.eqEx?.length || filters.mv.length || filters.mvEx?.length || filters.cat.length || filters.wt.length || filters.bp?.length || filters.durMin != null || filters.durMax != null
  const activeFilterCount = (sourceFilter !== 'all' ? 1 : 0) + filters.eq.length + (filters.eqEx?.length || 0) + filters.mv.length + (filters.mvEx?.length || 0) + filters.cat.length + filters.wt.length + (filters.bp?.length || 0) + (filters.durMin != null || filters.durMax != null ? 1 : 0)

  function clearFilters() {
    setFilters({ eq: [], eqEx: [], mv: [], mvEx: [], cat: [], wt: [], bp: [], durMin: null, durMax: null, includeNoDur: true })
    setQuery('')
    setSourceFilter('all')
    setAiActive(null)
    setAiError('')
    setPage(1)
  }

  async function aiSearch() {
    const q = query.trim()
    if (!q || aiLoading) return
    setAiLoading(true)
    setAiError('')
    try {
      const res = await fetch('/api/search-workouts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: q,
          vocab: {
            equipment: allEquipment,
            movements: allMovements,
            categories: allCategories,
            workoutTypes: allWorkoutTypes,
            bodyParts: allBodyParts,
          },
        }),
      })
      const data = await res.json()
      if (!res.ok || data.error) throw new Error(data.error || 'Search failed')
      const f = data.filters || {}
      const hasDur = f.durMin != null || f.durMax != null
      setFilters({
        eq: f.eq || [], eqEx: f.eqEx || [], mv: f.mv || [], mvEx: f.mvEx || [],
        cat: f.cat || [], wt: f.wt || [], bp: f.bp || [],
        durMin: f.durMin ?? null, durMax: f.durMax ?? null,
        // when a duration was requested, exclude workouts with no duration data
        includeNoDur: !hasDur,
      })
      setQuery(f.keywords || '')
      setSourceFilter('all')
      setAiActive(q)
      setPage(1)
    } catch (e) {
      setAiError(e.message || 'Search failed')
    }
    setAiLoading(false)
  }


  // Find similar workouts to a given workout
  function getSimilar(workout) {
    if (!workout) return []
    return workouts
      .filter(w => w.id !== workout.id)
      .map(w => {
        let score = 0
        // Shared equipment
        const sharedEq = (w.equipment || []).filter(e => workout.equipment?.includes(e)).length
        score += sharedEq * 2
        // Shared movements
        const sharedMv = (w.movement_categories || []).filter(m => workout.movement_categories?.includes(m)).length
        score += sharedMv * 3
        // Shared workout type
        const sharedWt = (w.workout_types || []).filter(t => workout.workout_types?.includes(t)).length
        score += sharedWt * 2
        // Similar duration
        if (w.estimated_duration_mins && workout.estimated_duration_mins) {
          const diff = Math.abs(w.estimated_duration_mins - workout.estimated_duration_mins)
          if (diff <= 5) score += 3
          else if (diff <= 10) score += 1
        }
        // Shared body parts
        const sharedBp = (w.body_parts || []).filter(b => workout.body_parts?.includes(b)).length
        score += sharedBp
        return { ...w, similarityScore: score }
      })
      .filter(w => w.similarityScore > 3)
      .sort((a, b) => b.similarityScore - a.similarityScore)
      .slice(0, 3)
  }

  async function quickLogParse() {
    if (!session) { onAuthRequired(); return }
    if (!qlText.trim()) return
    setQlLoading(true); setQlError(''); setQlParsed(null); setQlSaved(false)
    try {
      const res = await fetch('/api/log-workout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: qlText, names: workouts.map(w => w.name) })
      })
      const data = await res.json()
      if (data.error) { setQlError(data.error); setQlLoading(false); return }
      let matchedWorkout = null
      if (data.matched) {
        const mn = String(data.matched).trim().toLowerCase()
        matchedWorkout = workouts.find(w => w.name.trim().toLowerCase() === mn)
          || workouts.find(w => w.name.trim().toLowerCase().includes(mn) || mn.includes(w.name.trim().toLowerCase()))
      }
      const d = new Date(); d.setDate(d.getDate() - (parseInt(data.days_ago) || 0))
      if (!matchedWorkout && !data.new_workout) {
        setQlError("Couldn't understand that — try including the workout name or activity")
      } else {
        setQlParsed({
          matchedWorkout,
          newWorkout: matchedWorkout ? null : data.new_workout,
          score: data.score || '',
          is_rx: data.is_rx !== false,
          notes: data.notes || '',
          date: d.toISOString().slice(0, 10),
        })
      }
    } catch (err) { setQlError(err.message || 'Parse failed') }
    setQlLoading(false)
  }

  async function quickLogConfirm() {
    if (!session || !qlParsed) return
    setQlLoading(true); setQlError('')
    try {
      let workoutId = qlParsed.matchedWorkout?.id
      if (!workoutId && qlParsed.newWorkout) {
        const nw = qlParsed.newWorkout
        const { data: created, error: werr } = await supabase.from('workouts').insert({
          name: nw.name || 'Quick Logged Activity',
          description: nw.description || qlText,
          score_type: nw.score_type || 'None',
          estimated_duration_mins: nw.estimated_duration_mins || null,
          equipment: nw.equipment || ['Bodyweight'],
          workout_types: nw.workout_types || [],
          movement_categories: nw.movement_categories || [],
          body_parts: nw.body_parts || [],
          categories: [],
          visibility: 'private',
          created_by: session.user.id,
          source: 'quick-log',
        }).select('id').single()
        if (werr) throw werr
        workoutId = created.id
      }
      if (!workoutId) throw new Error('No workout to log against')
      const { error: lerr } = await supabase.from('performance_log').insert({
        user_id: session.user.id,
        workout_id: workoutId,
        completed_at: qlParsed.date,
        score: qlParsed.score || null,
        notes: qlParsed.notes || null,
        is_rx: qlParsed.is_rx,
      })
      if (lerr) throw lerr
      setQlSaved(true); setQlParsed(null); setQlText(''); setQlOpen(false)
      if (onWorkoutsChanged) onWorkoutsChanged()
      setTimeout(() => setQlSaved(false), 3000)
    } catch (err) { setQlError(err.message || 'Save failed') }
    setQlLoading(false)
  }

  return (
    <>
      <div className="srow">
        <div className="sbox">
          <input type="text" placeholder="Search keywords — or describe a workout and tap ✨" value={query}
            onChange={e => { setQuery(e.target.value); setPage(1) }}
            onKeyDown={e => { if (e.key === 'Enter') aiSearch() }} />
          {query && <button className="sbox-clear" onClick={() => { setQuery(''); setPage(1) }}>✕</button>}
        </div>
        <button className="rbtn" onClick={aiSearch} disabled={aiLoading} title="Search with AI — describe what you want">{aiLoading ? '⏳' : '✨ AI'}</button>
      </div>

      <div className="action-row">
        <button className={`action-btn${showFilters ? ' on' : ''}`} onClick={() => { setShowFilters(!showFilters); setQlOpen(false) }}>⚙️ Filters{activeFilterCount > 0 ? ` · ${activeFilterCount}` : ''}</button>
        <button className="action-btn" onClick={() => { if (!session) { onAuthRequired(); return } setShowNewModal(true) }}>➕ New Workout</button>
        <button className={`action-btn${qlOpen ? ' on' : ''}`} onClick={() => { if (!session) { onAuthRequired(); return } setQlOpen(!qlOpen); setShowFilters(false); setQlError('') }}>⚡ Quick Log</button>
      </div>

      <div style={{ margin: '4px 0 8px' }}>
        {qlSaved && (
          <div className="ql-saved">✓ Logged!</div>
        )}
        {qlOpen && (
          <div className="ql-panel">
            <div className="ql-row">
              <input className="ql-input"
                placeholder='e.g. "did Chad in 39:55 rx" or "ran 10k easy, 52:10"'
                value={qlText} onChange={e => setQlText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') quickLogParse() }} />
              <button className="rbtn" onClick={quickLogParse} disabled={qlLoading}>{qlLoading ? '⏳' : '⚡'}</button>
              <button className="rbtn" onClick={() => { setQlOpen(false); setQlParsed(null); setQlError(''); setQlText('') }}>✕</button>
            </div>

            {qlError && (
              <div className="ql-error">{qlError}</div>
            )}

            {qlParsed && (
              <div className="ql-confirm">
                <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 8 }}>
                  {qlParsed.matchedWorkout ? qlParsed.matchedWorkout.name : (qlParsed.newWorkout?.name || 'Activity')}
                  {!qlParsed.matchedWorkout && <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--acc)', marginLeft: 8 }}>NEW · saved as private workout</span>}
                </div>

                <label className="ai-edit-label">Score</label>
                <input className="doc-suit-input" value={qlParsed.score}
                  onChange={e => setQlParsed({ ...qlParsed, score: e.target.value })}
                  placeholder="e.g. 39:55" style={{ marginBottom: 8 }} />

                <div className="cr" style={{ marginBottom: 8 }}>
                  <button className={`ch${qlParsed.is_rx ? ' on' : ''}`} onClick={() => setQlParsed({ ...qlParsed, is_rx: true })}>Rx</button>
                  <button className={`ch${!qlParsed.is_rx ? ' on' : ''}`} onClick={() => setQlParsed({ ...qlParsed, is_rx: false })}>Scaled</button>
                </div>

                <label className="ai-edit-label">Date</label>
                <input type="date" className="doc-suit-input" value={qlParsed.date}
                  onChange={e => setQlParsed({ ...qlParsed, date: e.target.value })}
                  style={{ width: 170, marginBottom: 8 }} />

                <label className="ai-edit-label">Notes</label>
                <input className="doc-suit-input" value={qlParsed.notes}
                  onChange={e => setQlParsed({ ...qlParsed, notes: e.target.value })}
                  placeholder="optional" style={{ marginBottom: 10 }} />

                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="doc-start-btn" style={{ flex: 1, fontSize: 14 }} onClick={quickLogConfirm} disabled={qlLoading}>✓ Confirm & Log</button>
                  <button className="doc-ctrl" onClick={() => setQlParsed(null)}>Cancel</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {showFilters && (
        <>
        <div className="source-filter">
        <button className={`sf-btn${sourceFilter === 'all' ? ' on' : ''}`} onClick={() => { setSourceFilter('all'); setPage(1) }}>All</button>
        <button className={`sf-btn sf-official${sourceFilter === 'official' ? ' on' : ''}`} onClick={() => { setSourceFilter('official'); setPage(1) }}>🦍 Official</button>
        <button className={`sf-btn sf-community${sourceFilter === 'community' ? ' on' : ''}`} onClick={() => { setSourceFilter('community'); setPage(1) }}>👤 Community</button>
        {session && <button className={`sf-btn sf-mine${sourceFilter === 'mine' ? ' on' : ''}`} onClick={() => { setSourceFilter('mine'); setPage(1) }}>🔒 My Workouts</button>}
        <button className={`sf-btn sf-travel${sourceFilter === 'traveling' ? ' on' : ''}`} onClick={() => {
          if (sourceFilter === 'traveling') {
            setSourceFilter('all')
            setFilters({ eq: [], eqEx: [], mv: [], mvEx: [], cat: [], wt: [], bp: [], durMin: null, durMax: null, includeNoDur: true })
          } else {
            setSourceFilter('traveling')
            setFilters({ eq: ['Bodyweight'], eqEx: [], mv: [], mvEx: [], cat: [], wt: [], bp: [], durMin: null, durMax: null, includeNoDur: true })
          }
          setPage(1)
        }}>✈️ Traveling</button>
        {session && (
          <button className={`sf-btn sf-mygym${sourceFilter === 'mygym' ? ' on' : ''}`} onClick={() => {
            if (!profile?.my_equipment?.length) {
              alert('Set up My Gym first! Go to your Profile → Edit Profile and select the equipment you have.')
              return
            }
            setSourceFilter(sourceFilter === 'mygym' ? 'all' : 'mygym')
            if (sourceFilter !== 'mygym') setFilters({ eq: [], eqEx: [], mv: [], mvEx: [], cat: [], wt: [], bp: [], durMin: null, durMax: null, includeNoDur: true })
            setPage(1)
          }}>🏠 My Gym</button>
        )}
      </div>
        <Filters
          filters={filters}
          setFilters={(f) => { setFilters(typeof f === 'function' ? f(filters) : f); setPage(1) }}
          allEquipment={allEquipment}
          allMovements={allMovements}
          allCategories={allCategories}
          allWorkoutTypes={allWorkoutTypes}
          allBodyParts={allBodyParts}
        />
        </>
      )}

      {presetLabel && (
        <div style={{ margin: '4px 0 8px', padding: '8px 12px', borderRadius: 8, fontSize: 13, border: '1px solid var(--acc, #888)', background: 'var(--bg2, rgba(128,128,128,0.08))', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span>🧬 Training for <strong>{presetLabel}</strong></span>
          <span onClick={() => { setPresetLabel(null); clearFilters() }} style={{ cursor: 'pointer', textDecoration: 'underline', opacity: 0.8 }}>clear</span>
        </div>
      )}
      {(aiActive || aiError) && (
        <div style={{
          margin: '4px 0 8px', padding: '8px 12px', borderRadius: 8, fontSize: 13,
          border: `1px solid ${aiError ? 'var(--err, #c0392b)' : 'var(--acc, #888)'}`,
          background: 'var(--bg2, rgba(128,128,128,0.08))', display: 'flex',
          alignItems: 'center', gap: 8, flexWrap: 'wrap'
        }}>
          {aiError
            ? <span style={{ color: 'var(--err, #c0392b)' }}>AI search failed: {aiError}</span>
            : <span>✨ AI results for <strong>"{aiActive}"</strong></span>}
          <span onClick={clearFilters} style={{ cursor: 'pointer', textDecoration: 'underline', opacity: 0.8 }}>clear</span>
        </div>
      )}

      {showNewModal && <NewWorkoutModal onClose={() => setShowNewModal(false)} onSaved={() => { setShowNewModal(false); onWorkoutsChanged() }} session={session} isAdmin={isAdmin} />}



      <div className="rbar">
        <span className="rcnt">
          {filtered.length} workout{filtered.length !== 1 ? 's' : ''}
          {hasFilters && <span className="clr" onClick={clearFilters}>clear filters</span>}
        </span>
        <select className="ssel" value={sort} onChange={e => setSort(e.target.value)}>
          <option value="added">Recently Added</option>
          <option value="newest">Newest (by date)</option>
          <option value="oldest">Oldest (by date)</option>
          <option value="name">By name</option>
          <option value="dur_s">Duration ↑</option>
          <option value="dur_l">Duration ↓</option>
        </select>
      </div>


      <div className="wl">
        {workouts.length === 0 && !query ? (
          Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="skeleton-card">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div className="skeleton-line" style={{ width: '8px', height: '8px', borderRadius: '50%', flexShrink: 0, marginBottom: 0 }}></div>
                <div className="skeleton-line title" style={{ marginBottom: 0 }}></div>
              </div>
              <div className="skeleton-tags" style={{ paddingLeft: '16px' }}>
                <div className="skeleton-line tag"></div>
                <div className="skeleton-line tag" style={{ width: '45px' }}></div>
                <div className="skeleton-line tag" style={{ width: '55px' }}></div>
              </div>
            </div>
          ))
        ) : items.length === 0 ? (
          /* In-flow discovery: nothing matched → offer the AI Generator right here */
          <div className="wl-empty">
            <div className="wl-empty-icon">🦍</div>
            <b>No workouts match.</b>
            <p>Loosen a filter or search — or have the AI build exactly what you're looking for.</p>
            {onGenerateAI && <button className="ab p" onClick={onGenerateAI}>🤖 Generate one with AI</button>}
          </div>
        ) : items.map(w => (
          <WorkoutCard
            key={w.id}
            workout={w}
            isFav={favorites.has(w.id)}
            toggleFavorite={toggleFavorite}
            session={session}
            isAdmin={isAdmin}
            onAuthRequired={onAuthRequired}
            onWorkoutsChanged={onWorkoutsChanged}
            getSimilar={getSimilar}
            collections={collections}
            onCollectionsChanged={onCollectionsChanged}
          />
        ))}
      </div>

      {totalPages > 1 && (
        <div className="pgr">
          {page > 1 && <button className="pg" onClick={() => { setPage(page - 1); window.scrollTo(0, 250) }}>←</button>}
          {Array.from({ length: Math.min(9, totalPages) }, (_, i) => {
            let p
            if (totalPages <= 9) p = i + 1
            else if (page <= 5) p = i + 1
            else if (page >= totalPages - 4) p = totalPages - 8 + i
            else p = page - 4 + i
            return <button key={p} className={`pg${page === p ? ' cur' : ''}`} onClick={() => { setPage(p); window.scrollTo(0, 250) }}>{p}</button>
          })}
          {page < totalPages && <button className="pg" onClick={() => { setPage(page + 1); window.scrollTo(0, 250) }}>→</button>}
        </div>
      )}
    </>
  )
}
